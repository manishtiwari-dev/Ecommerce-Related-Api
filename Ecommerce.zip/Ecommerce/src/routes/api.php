<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\Ecommerce\Http\Controllers\ProductController;

use Modules\Ecommerce\Http\Controllers\BrandController;
use Modules\Ecommerce\Http\Controllers\CategoryController;
use Modules\Ecommerce\Http\Controllers\FieldsGroupController;
use Modules\Ecommerce\Http\Controllers\ProductTypeController;
use Modules\Ecommerce\Http\Controllers\FieldController;
use Modules\Ecommerce\Http\Controllers\ProductsOptionsValuesController;
use Modules\Ecommerce\Http\Controllers\SupplierController;
use Modules\Ecommerce\Http\Controllers\OrderController;
use Modules\Ecommerce\Http\Controllers\ReviewsController;
use Modules\Ecommerce\Http\Controllers\FeaturedGroupController;
use Modules\Ecommerce\Http\Controllers\FeaturedProductController;
use Modules\Ecommerce\Http\Controllers\FeatureController;
use Modules\Ecommerce\Http\Controllers\ProductOptionsController;
use Modules\Ecommerce\Http\Controllers\ListingOptionsController;
use Modules\Ecommerce\Http\Controllers\CouponController;








/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => ['ApiTokenCheck'],'prefix'=>"api/"], function() {
    
    // Product API
    Route::group(['prefix' => 'product'], function() {
        Route::post('/', [ProductController::class,'index']);
        Route::post('/create', [ProductController::class,'create']);
        Route::post('/store', [ProductController::class,'store']);
        Route::post('/edit', [ProductController::class,'edit']);
        Route::post('/show', [ProductController::class,'show']);
        Route::post('/update', [ProductController::class,'update']);
        Route::post('/changeStatus', [ProductController::class,'changeStatus']);
    });
    //end Product API

    
    
     //Brand API
    Route::group(['prefix' => 'brand'], function() {
        Route::post('/', [BrandController::class,'index']);
        Route::post('/store', [BrandController::class,'store']);
        Route::post('/edit', [BrandController::class,'edit']);
        Route::post('/update', [BrandController::class,'update']);
        Route::post('/delete', [BrandController::class,'destroy']);
        Route::post('/changeStatus', [BrandController::class,'changeStatus']);
    });
    //end Brand API


         //Coupun API
         Route::group(['prefix' => 'coupun'], function() {
            Route::post('/', [CouponController::class,'index']);
            Route::post('/store', [CouponController::class,'store']);
            Route::post('/edit', [CouponController::class,'edit']);
            Route::post('/update', [CouponController::class,'update']);
            Route::post('/delete', [CouponController::class,'destroy']);
            Route::post('/view', [CouponController::class,'view']);
            Route::post('/changeStatus', [CouponController::class,'changeStatus']);
        });
        //end Coupun API
    
     //Categories API
    Route::group(['prefix' => 'categories'], function() {
        Route::post('/create_sub_category', [CategoryController::class,'create_sub_category']);
        Route::post('/', [CategoryController::class,'index']);
        Route::post('/store', [CategoryController::class,'store']);
        Route::post('/edit', [CategoryController::class,'edit']);
        Route::post('/update', [CategoryController::class,'update']);
        Route::post('/changeStatus', [CategoryController::class,'changeStatus']);
       Route::post('/isfeatured', [CategoryController::class,'is_featured']);
       Route::post('/sortOrder', [CategoryController::class,'sortOrder']);


    });
     //end Categories API

    
    
     //Fieldsgroup API  
    Route::group(['prefix' => 'fieldsgroup'], function() {
        Route::post('/', [FieldsGroupController::class,'index']);
        Route::post('/store', [FieldsGroupController::class,'store']);
        Route::post('/edit', [FieldsGroupController::class,'edit']);
        Route::post('/update', [FieldsGroupController::class,'update']);
        Route::post('/changeStatus', [FieldsGroupController::class,'changeStatus']);
    });
    //end Fieldsgroup API
     
     //Field API
    Route::group(['prefix' => 'field'], function() {
        Route::post('/', [FieldController::class,'index']);
        Route::post('/store', [FieldController::class,'store']);
        Route::post('/edit', [FieldController::class,'edit']);
        Route::post('/update', [FieldController::class,'update']);
        Route::post('/changeStatus', [FieldController::class,'changeStatus']);
    });
    //end Field API

     //Product Type
    Route::group(['prefix' => 'product_type'], function() {
        Route::post('/', [ProductTypeController::class,'index']);
        Route::post('/store', [ProductTypeController::class,'store']);
        Route::post('/edit', [ProductTypeController::class,'edit']);
        Route::post('/update', [ProductTypeController::class,'update']);
        Route::post('/changeStatus', [ProductTypeController::class,'changeStatus']);
        Route::post('/sortOrder', [ProductTypeController::class,'sortOrder']);

    });
    //end Product Type

     //Product Options API   
    Route::group(['prefix' => 'product_options'], function() {
        Route::post('/', [ProductOptionsController::class,'index']);
        Route::post('/store', [ProductOptionsController::class,'store']);
        Route::post('/edit', [ProductOptionsController::class,'edit']);
        Route::post('/update', [ProductOptionsController::class,'update']);
        Route::post('/changeStatus', [ProductOptionsController::class,'changeStatus']);
        Route::post('/destroy', [ProductOptionsController::class,'destroy']);

    });
    //end Product Options API

     //Product Options API   
    Route::group(['prefix' => 'listing_options'], function() {
        Route::post('/', [ListingOptionsController::class,'index']);
        
    });
    //end Product Options API

     //Product Options Value  API
    Route::group(['prefix' => 'product_options_value'], function() {
        Route::post('/', [ProductsOptionsValuesController::class,'index']);
        Route::post('/store', [ProductsOptionsValuesController::class,'store']);
        Route::post('/edit', [ProductsOptionsValuesController::class,'edit']);
        Route::post('/update', [ProductsOptionsValuesController::class,'update']);
        Route::post('/changeStatus', [ProductsOptionsValuesController::class,'changeStatus']);
        Route::post('/sortOrder', [ProductsOptionsValuesController::class,'sortOrder']);
        Route::post('/destroy', [ProductsOptionsValuesController::class,'destroy']);
        Route::post('/list', [ProductsOptionsValuesController::class,'view']);
    });
    //end Product Options Value API

     //Supplier API
    Route::group(['prefix' => 'supplier'], function() {
        Route::post('/', [SupplierController::class,'index']);
        Route::post('/store', [SupplierController::class,'store']);
        Route::post('/create', [SupplierController::class,'create']);
        Route::post('/edit', [SupplierController::class,'edit']);
        Route::post('/update', [SupplierController::class,'update']);
        Route::post('/changeStatus', [SupplierController::class,'changeStatus']);
    });
    //end Supplier API
    
             //Web Order prefix

            Route::group(['prefix'=>'orders'], function(){
            Route::post('/', [OrderController::class,'index']); 
            Route::post('/detail', [OrderController::class,'orderDetails']); 
            Route::post('/changeStatus', [OrderController::class,'changeStatus']);
            Route::post('/order-details-pdf', [OrderController::class,'orderdetailspdf']);
            // Route::post('/order-filter', [OrderController::class,'OrderFilter']);
            Route::post('/order-updates', [OrderController::class,'UpdateOrderStatus']);
            
        });    

        //end prefix 
        
        //Web review Prefix

        Route::group(['prefix'=>'reviews'], function(){
            Route::post('/', [ReviewsController::class,'index']);
            Route::post('/store', [ReviewsController::class,'store']);
            Route::post('/create', [ReviewsController::class,'create']); 
            Route::post('/changeStatus', [ReviewsController::class,'changeStatus']);
            
        }); 

        //end reviews prefix 

        //Featured Group Prefix

       Route::group(['prefix'=>'feature'], function(){
            Route::post('/', [FeaturedGroupController::class,'index']);
            Route::post('/store', [FeaturedGroupController::class,'store']);
            Route::post('/edit', [FeaturedGroupController::class,'edit']);
            Route::post('/update', [FeaturedGroupController::class,'update']);
            Route::post('/delete', [FeaturedGroupController::class,'destroy']);
           Route::post('/changeStatus', [FeaturedGroupController::class,'changeStatus']);
            
        }); 
        
        // Featured Product

        Route::group(['prefix'=>'featureProduct'], function(){
            Route::post('/', [FeaturedProductController::class,'index']);
            Route::post('/store', [FeaturedProductController::class,'store']);
            Route::post('/edit', [FeaturedProductController::class,'edit']);
            Route::post('/update', [FeaturedProductController::class,'update']);
            Route::post('/delete', [FeaturedProductController::class,'destroy']);
            Route::post('/changeStatus', [FeaturedProductController::class,'changeStatus']);
            
        }); 

       //Web Feature

          Route::group(['prefix'=>'webfeature'], function(){
            Route::post('/', [FeatureController::class,'index']);
            Route::post('/store', [FeatureController::class,'store']);
            Route::post('/edit', [FeatureController::class,'edit']);
            Route::post('/update', [FeatureController::class,'update']);
            Route::post('/changeStatus', [FeatureController::class,'changeStatus']);
            
        }); 



});

