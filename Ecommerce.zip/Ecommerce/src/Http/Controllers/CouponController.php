<?php

namespace Modules\Ecommerce\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Modules\Ecommerce\Models\Coupon;
use Modules\Ecommerce\Models\LandingCoupon;


use Illuminate\Http\Request;
use App\Models\Language;

use ApiHelper;



class CouponController extends Controller
{
    public $page = 'coupon';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {


        //Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();

        $search = $request->search;
        $sortBy = $request->sortBy;
        $orderBy = $request->orderBy;
        $language = $request->language;

        /*Fetching subscriber data*/
        if ($userType == 'subscriber') {

            $coupun_query = Coupon::query();
        } else {
            $coupun_query = LandingCoupon::query();
        }







        /*Checking if search data is not empty*/
        if (!empty($search))
            $coupun_query = $coupun_query
                ->where("coupon_name", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBy) && !empty($orderBy))
            $coupun_query = $coupun_query->orderBy($sortBy, $orderBy);
        else
            $coupun_query = $coupun_query->orderBy('coupon_id', 'DESC');

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;

        $coupun_count = $coupun_query->count();

        $coupan_list = $coupun_query->skip($skip)->take($perPage)->get();

        /*Binding data into a variable*/
        $res = [
            'data' => $coupan_list,
            'current_page' => $current_page,
            'total_records' => $coupun_count,
            'total_page' => ceil((int)$coupun_count / (int)$perPage),
            'per_page' => $perPage,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        if ($userType == 'subscriber') {
            $coupans = Coupon::create([
                'coupon_name' => $request->coupon_name,
                'coupon_code' => $request->coupon_code,
                'coupon_limit' => $request->coupon_limit,
                'active_at' => $request->active_at,
                'coupon_type' => 1,
                'expire_at' => $request->expire_at,
                'discount' => $request->discount,
                'discount_type' => $request->discount_type,
                'minimum_purchase' => $request->minimum_purchase,
                'maximum_discount' => $request->maximum_discount,
                'first_purchase_only' => $request->first_purchase_only,
                'multiple_use' => $request->multiple_use,
                'guest_checkout' => $request->guest_checkout,
                'status' => $request->status,

            ]);
        } else {
            $coupans = LandingCoupon::create([
                'coupon_name' => $request->coupon_name,
                'coupon_code' => $request->coupon_code,
                'coupon_limit' => $request->coupon_limit,
                'active_at' => $request->active_at,
                'coupon_type' => 1,
                'expire_at' => $request->expire_at,
                'discount' => $request->discount,
                'discount_type' => $request->discount_type,
                'minimum_purchase' => $request->minimum_purchase,
                'maximum_discount' => $request->maximum_discount,
                'first_purchase_only' => $request->first_purchase_only,
                'multiple_use' => $request->multiple_use,
                'guest_checkout' => $request->guest_checkout,
                'status' => $request->status,

            ]);
        }


        if ($coupans) {
            return ApiHelper::JSON_RESPONSE(true, $coupans, 'SUCCESS_COUPUN_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_COUPUN_ADD');
        }
    }

    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);


        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        //validation check 
        // $rules = [
        //     'source_id' => 'required',
        //     'industry_id' => 'required',
        //    // 'status_id' => 'required',
        //     'priority' => 'required',
        //     'company_name' => 'required|string',
        //     'website' => 'required|string',
        //     'address' => 'required|string',
        //     'city' => 'required|string',
        //     'state' => 'required|string',
        //     'zipcode' => 'required',
        //     'countries_id' => 'required',
        //     'phone' => 'required',
        //     'folllow_up' => 'required',
        //     //'followup_schedule' => 'required',
        // ];
        // $validator = Validator::make($request->all(), $rules);

        // if ($validator->fails())
        //     return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());



        $coupon_id = $request->coupon_id;
        if ($userType == 'subscriber') {
            $arra = [

                'coupon_name' => $request->coupon_name,
                'coupon_code' => $request->coupon_code,
                'coupon_limit' => $request->coupon_limit,
                'active_at' => $request->active_at,
                'coupon_type' => 1,
                'expire_at' => $request->expire_at,
                'discount' => $request->discount,
                'discount_type' => $request->discount_type,
                'minimum_purchase' => $request->minimum_purchase,
                'maximum_discount' => $request->maximum_discount,
                'first_purchase_only' => $request->first_purchase_only,
                'multiple_use' => $request->multiple_use,
                'guest_checkout' => $request->guest_checkout,
                'status' => $request->status,
            ];

            $coupuns = Coupon::where('coupon_id', $coupon_id)->update($arra);
        } else {
            $arra = [

                'coupon_name' => $request->coupon_name,
                'coupon_code' => $request->coupon_code,
                'coupon_limit' => $request->coupon_limit,
                'active_at' => $request->active_at,
                'coupon_type' => 1,
                'expire_at' => $request->expire_at,
                'discount' => $request->discount,
                'discount_type' => $request->discount_type,
                'minimum_purchase' => $request->minimum_purchase,
                'maximum_discount' => $request->maximum_discount,
                'first_purchase_only' => $request->first_purchase_only,
                'multiple_use' => $request->multiple_use,
                'guest_checkout' => $request->guest_checkout,
                'status' => $request->status,
            ];

            $coupuns = LandingCoupon::where('coupon_id', $coupon_id)->update($arra);
        }





        if ($coupuns) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_COUPUN_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_COUPUN_UPDATE');
        }
    }





    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $coupon_id = $request->coupon_id;
            $infoData = Coupon::find($coupon_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        } else {

            $coupon_id = $request->coupon_id;
            $infoData = LandingCoupon::find($coupon_id);
            $infoData->status = ($infoData->status == 0) ? 1 : 0;
            $infoData->save();
        }



        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_STATUS_UPDATE');
    }


    public function view(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $response = Coupon::find($request->coupon_id);
        } else {

            $response = LandingCoupon::find($request->coupon_id);
        }

        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }


    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $response = Coupon::find($request->coupon_id);
        } else {
            $response = LandingCoupon::find($request->coupon_id);
        }
        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }


    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        $coupon_id = $request->coupon_id;
        /*
        if(!ApiHelper::is_page_access($api_token,$this->BrandDelete)){
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
        }
        */
        $userType = ApiHelper::userType($api_token);
        if ($userType == 'subscriber') {
            $status = Coupon::where('coupon_id', $coupon_id)->delete();
        } else {
            // $response = LandingCoupon::find($request->coupon_id);
            $status = LandingCoupon::where('coupon_id', $coupon_id)->delete();
        }
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_COUPUN_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_COUPUN_DELETE');
        }
    }
}
