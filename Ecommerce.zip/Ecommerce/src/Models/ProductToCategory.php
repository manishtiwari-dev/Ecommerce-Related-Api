<?php

namespace Modules\Ecommerce\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class ProductToCategory extends Model
{
    use HasFactory;

    // protected $primaryKey = 'id';

    // protected $guarded = ['id'];

    protected $fillable = [
        'products_id',
        'categories_id',
        'sort_order'
    ];

    public $timestamps = false;

    public function getTable()
    {
        return config('dbtable.ecm_products_to_categories');
    }

    public function product()
    {
        return $this->belongsToMany(Product::class, config('dbtable.ecm_products'), 'product_id', 'product_id');
    }
}
