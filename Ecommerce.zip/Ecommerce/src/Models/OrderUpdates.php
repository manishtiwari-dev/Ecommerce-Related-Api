<?php

namespace Modules\Ecommerce\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Ecommerce\Models\OrderShipments;


class OrderUpdates extends Model
{
    use HasFactory;

    protected $primaryKey = 'id';

    public $timestamps = false;
    protected $guarded = ['id'];

    public function getTable()
    {
       return config('dbtable.web_order_updates');
    }

    public function shipmentStatus()
    {
        return $this->hasOne(OrderShipments::class, 'order_update_id', 'id');
    }

}
